# quarkus-batch-processor — Architecture Overview

## 1. Objetivo do projeto

O **quarkus-batch-processor** é uma biblioteca para processamento massivo de registros com foco em:

- baixo consumo de memória
- streaming de dados
- processamento em chunks
- controle transacional por lote
- tratamento de erro configurável
- retry para falhas transitórias

A ideia principal é evitar carregar grandes volumes de entidades em memória ao mesmo tempo, reduzindo o risco de `OutOfMemoryError` e melhorando a previsibilidade do processamento.

---

## 2. Organização do projeto

A estrutura principal do projeto está organizada por responsabilidade:

br.com.codenest 
├── config 
│ ├── ErrorStrategy 
│ ├── TransactionMode 
│ └── RetryStrategy 
├── contract 
│ ├── ChunkListener 
│ ├── Processor 
│ └── RecordErrorHandler 
├── engine 
│ ├── FastRecordProcessor 
│ ├── FastRecordProcessorImpl 
│ ├── ProcessingLoop 
│ ├── ProcessingMetricsLogger 
│ ├── RecordProcessingException 
│ └── ChunkExecutionResult 
├── result 
│ └── ProcessingResult



### 2.1 `contract`
Contém os contratos públicos da biblioteca.

Classes:
- `Processor`
- `ChunkListener`
- `RecordErrorHandler`

Responsabilidade:
definir como o consumidor da biblioteca interage com o motor de processamento.

---

### 2.2 `config`
Contém os tipos de configuração de comportamento.

Classes:
- `ErrorStrategy`
- `TransactionMode`
- `RetryStrategy`

Responsabilidade:
definir políticas de execução, erro, retry e transação.

---

### 2.3 `result`
Contém os objetos de retorno do processamento.

Classes:
- `ProcessingResult`

Responsabilidade:
informar o resultado final da execução, incluindo quantidade de registros processados, erros, retries, duração e throughput.

---

### 2.4 `engine`
Contém o núcleo da biblioteca.

Classes:
- `FastRecordProcessor`
- `FastRecordProcessorImpl`
- `ProcessingLoop`
- `ProcessingMetricsLogger`
- `RecordProcessingException`
- `ChunkExecutionResult`

Responsabilidade:
executar o processamento, controlar chunks, lidar com transações, métricas e fluxo interno.

---

### 2.5 `sample`
Contém exemplos de uso da biblioteca.

Classes:
- `CustomerBatchService`

Responsabilidade:
mostrar como a biblioteca pode ser utilizada em uma aplicação Quarkus.

---

## 3. Fluxo de uso da biblioteca

O uso da biblioteca acontece em etapas:

1. o consumidor injeta `FastRecordProcessor`
2. escolhe a entidade com `source(...)`
3. configura query, parâmetros, chunk, estratégia de erro, retry e transação
4. chama `run()`
5. o motor processa os registros em streaming e em chunks
6. o resultado final é retornado em `ProcessingResult`

Exemplo:
java ProcessingResult result = fastRecordProcessor .source(CustomerEntity.class) .processorName("active-customer-import") .loggingEnabled(true) .progressLogEveryChunks(10) .query("select c from CustomerEntity c where c.active = :active") .params(Map.of("active", true)) .chunkSize(2000) .transactionMode(TransactionMode.CHUNK) .onError(ErrorStrategy.CONTINUE_ON_ERROR) .retryStrategy(RetryStrategy.fixedDelay(3, 250, RuntimeException.class)) .onRecordError((customer, error) -> { System.err.println("Falha definitiva no cliente " + customer.getId() + ": " + error.getMessage()); }) .onProcess(customer -> { System.out.println("Processando cliente: " + customer.getName()); }) .onChunkComplete(processed -> { System.out.println("Chunk concluído. Total processado com sucesso até agora: " + processed); }) .run();


---

## 4. Passo a passo da execução

### 4.1 Entrada pelo `FastRecordProcessor`
A classe `FastRecordProcessor` é o ponto de entrada do usuário.
Ela recebe a entidade informada em `source(...)` e cria a implementação interna `FastRecordProcessorImpl<T>`.

---

### 4.2 Configuração fluente
Antes da execução, o usuário configura o comportamento com métodos como:

- `query(...)`
- `params(...)`
- `chunkSize(...)`
- `transactionMode(...)`
- `onProcess(...)`
- `onError(...)`
- `retryStrategy(...)`
- `onRecordError(...)`
- `onChunkComplete(...)`

Essas chamadas apenas preparam a execução. O processamento real só começa quando `run()` é chamado.

---

### 4.3 Validação e montagem da configuração
Ao executar `run()`, a implementação valida se as informações mínimas necessárias foram configuradas, especialmente o `consumer` de processamento.

Depois disso, monta uma configuração consolidada interna, usada durante toda a execução.

---

### 4.4 Abertura da sessão Hibernate
O motor obtém o `SessionFactory` a partir do `EntityManager` e abre uma `StatelessSession`.

A escolha por `StatelessSession` é importante porque ela não mantém cache de primeiro nível, reduzindo o consumo de memória em processamentos massivos.

---

### 4.5 Execução da query em streaming
A query HQL é criada e executada em modo streaming com `ScrollableResults` e `ScrollMode.FORWARD_ONLY`.

Isso permite ler os dados de forma incremental, sem carregar todos os registros em memória de uma vez.

---

### 4.6 Adaptação para `Iterator`
Os resultados do Hibernate são encapsulados em um iterador interno (`ScrollableResultsIterator`), que simplifica a integração com o `ProcessingLoop`.

---

### 4.7 Papel do `ProcessingLoop`
O `ProcessingLoop` é responsável por:

- ler registros de forma incremental
- agrupar registros em chunks
- chamar o processador de chunk
- limpar referências ao final de cada bloco
- notificar progresso
- consolidar o resultado final

Esse componente é a peça responsável por manter o processamento previsível em memória.

---

### 4.8 Papel do `ChunkExecutionResult`
Cada chunk devolve um resultado parcial contendo:

- quantidade de processados com sucesso
- quantidade de erros
- quantidade de retries

Esse resultado parcial é acumulado até formar o `ProcessingResult` final.

---

### 4.9 Processamento por chunk
Quando um chunk fica cheio, o motor decide como processá-lo de acordo com o `TransactionMode`.

#### `TransactionMode.NONE`
O chunk é processado sem abertura explícita de transação por lote.

#### `TransactionMode.CHUNK`
O chunk é processado dentro de uma transação dedicada:

1. abre transação
2. processa os registros do bloco
3. commita a transação
4. se algo falhar, executa rollback

---

### 4.10 Processamento por registro
Dentro do chunk, cada registro é entregue ao `consumer` configurado em `onProcess(...)`.

Se houver falha:
- o retry é aplicado, se configurado
- a falha definitiva é enviada para `onRecordError(...)`
- a estratégia `FAIL_FAST` ou `CONTINUE_ON_ERROR` define se o fluxo continua ou para

---

### 4.11 Retry
A política de retry é controlada por `RetryStrategy`.

Ela define:
- quantidade máxima de tentativas
- tempo de espera entre tentativas
- quais exceções permitem retry

Isso é útil para erros transitórios, como falhas temporárias de integração.

---

### 4.12 Callback de chunk
Ao final de cada chunk, o `ChunkListener` recebe a quantidade acumulada de registros processados com sucesso até aquele ponto.

---

### 4.13 Limpeza de referências
Após cada chunk, o motor executa limpeza de referências com `entityManager.clear()`.

Isso ajuda a manter o contexto limpo e reduzir retenção de objetos durante processamentos longos.

---

### 4.14 Logging e métricas
Se o logging estiver habilitado, a execução registra:

- início do processamento
- progresso por chunk
- fim do processamento
- falhas

As métricas principais incluem:
- processados
- erros
- retries
- duração
- throughput

---

### 4.15 Resultado final
Ao final do fluxo, o método `run()` devolve um `ProcessingResult`.

Ele pode ser usado para:
- auditoria
- observabilidade
- monitoramento
- dashboards
- métricas operacionais

---

## 5. Papel de cada classe

### `FastRecordProcessor`
Ponto de entrada da biblioteca.

### `Processor`
Contrato fluente para configuração e execução.

### `FastRecordProcessorImpl`
Implementação principal do motor.

### `ProcessingLoop`
Responsável por particionar e orquestrar os chunks.

### `ChunkExecutionResult`
Resultado parcial de cada chunk.

### `ProcessingResult`
Resultado final consolidado da execução.

### `RetryStrategy`
Configuração de retry por registro.

### `ErrorStrategy`
Configuração da política de tratamento de erro.

### `TransactionMode`
Configuração do modo transacional.

### `ChunkListener`
Callback ao final de cada chunk.

### `RecordErrorHandler`
Callback para falhas definitivas de registros.

### `ProcessingMetricsLogger`
Responsável pelos logs técnicos da execução.

### `RecordProcessingException`
Exceção padronizada da biblioteca.

---

## 6. Pontos fortes da arquitetura

- uso de `StatelessSession` para reduzir consumo de memória
- streaming de dados sem carregar todos os registros
- controle de chunk configurável
- retry configurável
- estratégia de erro configurável
- possibilidade de transação por chunk
- métricas e logging integrados
- API fluente e extensível

---

## 7. Pontos de atenção

### 7.1 Streaming + transação
O comportamento com `TransactionMode.CHUNK` deve ser validado em ambiente real com PostgreSQL, pois cursor de leitura e fronteiras transacionais podem variar conforme driver e banco.

### 7.2 Continuação com erro
Quando `ErrorStrategy.CONTINUE_ON_ERROR` é usado junto com `TransactionMode.CHUNK`, o chunk pode ser commitado mesmo contendo erros de registros individuais, dependendo da lógica executada no `consumer`.

### 7.3 Camada `sample`
A pasta `sample` não faz parte do motor da biblioteca; ela existe apenas como referência de uso.

---

## 8. Resumo final

O quarkus-batch-processor é um motor de processamento massivo orientado a chunks, com leitura em streaming, foco em memória, retry configurável, tratamento de erros, observabilidade e suporte a transação por lote.

Seu objetivo é permitir que grandes volumes de dados sejam processados com previsibilidade, extensibilidade e segurança operacional.