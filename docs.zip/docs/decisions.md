# quarkus-batch-processor — Architectural Decisions

## 1. Objetivo deste documento

Este documento registra as principais decisões arquiteturais do projeto quarkus-batch-processor, junto com seus motivos,
benefícios e pontos de atenção.

A ideia é preservar o contexto técnico por trás das escolhas feitas no projeto.

---

## 2. Decisão: usar `StatelessSession`

### Decisão

O projeto utiliza `StatelessSession` do Hibernate para leitura massiva de registros.

### Motivo

A `Session` tradicional mantém cache de primeiro nível, o que pode aumentar muito o consumo de memória em processamentos
extensos.

### Benefícios

- menor retenção de entidades em memória
- menor pressão no heap
- melhor adequação para grandes volumes

### Trade-off

- menos conveniências do ciclo de vida tradicional do Hibernate
- necessidade de maior cuidado com contexto transacional

---

## 3. Decisão: usar streaming com `ScrollableResults`

### Decisão

A leitura dos registros é feita em modo streaming com `ScrollableResults` e `ScrollMode.FORWARD_ONLY`.

### Motivo

Evitar carregar todos os resultados em memória ao mesmo tempo.

### Benefícios

- processamento incremental
- footprint de memória mais previsível
- melhor escalabilidade para grandes volumes

### Trade-off

- exige teste real com banco e driver
- interação com fronteiras transacionais pode variar conforme ambiente

---

## 4. Decisão: processar em chunks

### Decisão

O projeto adota processamento em blocos (`chunks`) configuráveis.

### Motivo

Permitir controle explícito do volume de dados mantido em memória e do tamanho das unidades de trabalho.

### Benefícios

- equilíbrio entre desempenho e uso de memória
- ponto natural para limpeza de referências
- ponto natural para transação por lote
- ponto natural para logging de progresso

### Trade-off

- escolha inadequada de chunk size pode prejudicar desempenho
- chunks muito grandes podem aumentar consumo de memória
- chunks muito pequenos podem aumentar overhead

---

## 5. Decisão: expor uma Fluent API

### Decisão

A biblioteca expõe uma API fluente baseada em `Processor<T>`.

### Motivo

Permitir configuração declarativa e legível da execução.

### Benefícios

- boa experiência de uso
- legibilidade
- facilidade de evolução
- menor acoplamento com detalhes internos

### Trade-off

- exige cuidado com validação tardia
- mudanças no contrato público precisam ser feitas com cautela

---

## 6. Decisão: separar contratos públicos de implementação

### Decisão

O projeto separa contratos em `contract` e implementação em `engine`.

### Motivo

Evitar mistura entre interface pública e mecanismo interno.

### Benefícios

- organização mais clara
- melhor manutenção
- menor confusão arquitetural
- mais espaço para evolução da implementação

### Trade-off

- aumenta o número de pacotes
- exige disciplina para manter fronteiras claras

---

## 7. Decisão: mover enums e estratégias para `config`

### Decisão

Enums e objetos de configuração ficam em `config`.

### Motivo

Eles representam políticas de comportamento, não execução.

### Benefícios

- separação semântica mais clara
- melhor descoberta de configurações
- facilita crescimento de opções futuras

### Trade-off

- algumas classes podem ficar na fronteira entre configuração e engine
- exige critério de classificação

---

## 8. Decisão: retornar `ProcessingResult`

### Decisão

O método `run()` retorna um objeto estruturado com o resultado da execução.

### Motivo

A execução precisa produzir informação operacional útil, não apenas efeito colateral.

### Benefícios

- observabilidade
- auditoria
- métricas
- integração com monitoramento
- facilidade de teste

### Trade-off

- exige manutenção da compatibilidade do contrato de retorno
- incentiva crescimento do objeto de resultado, que deve ser controlado com cuidado

---

## 9. Decisão: suportar `ErrorStrategy`

### Decisão

A biblioteca permite configurar o comportamento em caso de erro por registro.

### Opções atuais

- `FAIL_FAST`
- `CONTINUE_ON_ERROR`

### Motivo

Diferentes cenários exigem políticas distintas de tolerância a falhas.

### Benefícios

- flexibilidade operacional
- adaptação a cenários de ETL, sincronização ou integração
- menor acoplamento da regra de negócio com o motor

### Trade-off

- `CONTINUE_ON_ERROR` pode mascarar problemas se mal monitorado
- `FAIL_FAST` pode interromper cargas longas por falhas pontuais

---

## 10. Decisão: suportar `RetryStrategy`

### Decisão

A biblioteca permite configurar retries por registro.

### Motivo

Falhas transitórias são comuns em integrações e não devem necessariamente derrubar o processamento.

### Benefícios

- maior resiliência
- redução de falhas temporárias
- melhor aproveitamento da janela de processamento

### Trade-off

- retries aumentam o tempo total de execução
- retries mal configurados podem repetir sofrimento desnecessário
- nem toda falha deve ser reprocessada

---

## 11. Decisão: suportar `RecordErrorHandler`

### Decisão

Falhas definitivas por registro podem ser tratadas via callback.

### Motivo

Permitir que o chamador tenha visibilidade e ação sobre registros rejeitados.

### Benefícios

- auditoria
- dead-letter
- persistência de rejeições
- logging contextualizado

### Trade-off

- o callback pode introduzir lógica cara ou com side effects
- deve ser usado com cuidado em cargas massivas

---

## 12. Decisão: suportar `TransactionMode`

### Decisão

A biblioteca suporta modos transacionais configuráveis.

### Opções atuais

- `NONE`
- `CHUNK`

### Motivo

Alguns cenários precisam de isolamento por lote, enquanto outros preferem menor overhead transacional.

### Benefícios

- flexibilidade
- melhor adaptação a diferentes estratégias de consistência
- alinhamento com processamento em lotes

### Trade-off

- transação por chunk exige validação real com banco
- a interação entre streaming e transação pode variar

---

## 13. Decisão: transação por chunk em vez de transação global

### Decisão

Quando o modo transacional é `CHUNK`, cada bloco recebe sua própria transação.

### Motivo

Uma transação única para milhões de registros seria longa, pesada e operacionalmente arriscada.

### Benefícios

- menor tempo de retenção transacional
- rollback limitado ao chunk
- melhor isolamento por lote
- melhor adequação a processamentos longos

### Trade-off

- o resultado global pode ficar parcialmente commitado em caso de erro posterior
- exige clareza de negócio sobre atomicidade

---

## 14. Decisão: manter `ProcessingLoop` separado

### Decisão

A lógica de chunking foi isolada em `ProcessingLoop`.

### Motivo

Separar a mecânica de agrupamento da lógica de infraestrutura Hibernate e transação.

### Benefícios

- maior testabilidade
- separação de responsabilidades
- lógica mais fácil de evoluir

### Trade-off

- adiciona uma camada intermediária
- exige disciplina na troca de informações entre loop e engine

---

## 15. Decisão: manter `ChunkExecutionResult` separado de `ProcessingResult`

### Decisão

Resultados parciais de chunks e resultado final global são objetos diferentes.

### Motivo

O chunk tem escopo local, enquanto o resultado final tem escopo global.

### Benefícios

- modelagem mais clara
- melhor separação semântica
- facilita agregação incremental

### Trade-off

- mais uma classe no projeto
- exige atenção para manter coerência entre parcial e consolidado

---

## 16. Decisão: logging técnico no motor

### Decisão

O motor registra logs de início, progresso, fim e falha.

### Motivo

Processamentos massivos precisam de observabilidade operacional.

### Benefícios

- diagnóstico
- acompanhamento de progresso
- apoio a monitoramento
- visibilidade de throughput

### Trade-off

- log excessivo pode impactar desempenho
- volume de log precisa ser controlado

---

## 17. Decisão: permitir controlar frequência do log

### Decisão

A biblioteca permite configurar a frequência do log por chunks.

### Motivo

Reduzir ruído e custo operacional em execuções longas.

### Benefícios

- melhor controle de observabilidade
- menor volume de log
- ajuste fino por cenário

### Trade-off

- frequência muito baixa pode esconder progresso
- frequência muito alta pode gerar overhead

---

## 18. Decisão: manter `sample` separado do motor

### Decisão

Exemplos de uso ficam em `sample` e não no pacote do motor.

### Motivo

Exemplo não deve ser confundido com parte estrutural da biblioteca.

### Benefícios

- separação clara entre exemplo e engine
- menor risco de acoplamento indevido
- documentação prática embutida no projeto

### Trade-off

- o projeto passa a carregar código de exemplo em `main`
- em uma versão mais madura, isso pode migrar para outra estratégia

---

## 19. Decisão: usar organização por responsabilidade

### Decisão

Os pacotes foram estruturados por responsabilidade:

- `contract`
- `config`
- `engine`
- `result`
- `sample`

### Motivo

Melhor expressar o papel de cada parte do sistema e evitar nomes genéricos.

### Benefícios

- legibilidade
- manutenção
- escalabilidade da estrutura
- onboarding mais simples

### Trade-off

- exige critério para decidir em qual pacote uma nova classe deve ficar

---

## 20. Riscos conhecidos

### 20.1 Streaming + transação por chunk

Essa combinação precisa ser validada em banco real.

### 20.2 Continuação com erro + commit por chunk

Pode haver commit parcial de blocos mesmo com falhas de registros individuais.

### 20.3 Retry mal calibrado

Pode aumentar bastante o tempo da carga.

### 20.4 Consumer com side effects

A lógica passada em `onProcess(...)` pode impactar fortemente desempenho e comportamento transacional.

---

## 21. Possíveis decisões futuras

Algumas evoluções arquiteturais prováveis:

- política de rollback por erro dentro do chunk
- suporte a failure summary
- dead-letter nativo
- métricas mais estruturadas
- separação de subpacotes em `engine`
- namespace raiz `br.com.codenest.fastrecord`

---

## 22. Resumo final

As decisões arquiteturais do quarkus-batch-processor priorizam:

- previsibilidade de memória
- processamento incremental
- resiliência
- observabilidade
- clareza estrutural
- flexibilidade operacional

O projeto foi desenhado como uma biblioteca de processamento massivo, e não como um simples utilitário de consulta.