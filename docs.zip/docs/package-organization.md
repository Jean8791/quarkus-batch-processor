# quarkus-batch-processor — Package Organization

## 1. Objetivo deste documento

Este documento descreve a organização de pacotes do projeto quarkus-batch-processor e a responsabilidade de cada área do código.

O objetivo é facilitar:

- manutenção
- evolução da arquitetura
- onboarding de novos desenvolvedores
- consistência na criação de novos arquivos

---

## 2. Estrutura atual do projeto
br.com.codenest 
├── config 
├── contract 
├── engine 
├── result 
└── sample


A organização foi pensada por responsabilidade, e não por tipo técnico genérico.

---

## 3. Princípios da organização

A estrutura segue alguns princípios simples:

### 3.1 Separação por responsabilidade
Cada pacote deve representar um papel claro no sistema.

### 3.2 Clareza de intenção
O nome do pacote deve indicar o propósito do código ali contido.

### 3.3 Baixo acoplamento
Pacotes públicos e internos devem ter fronteiras o mais claras possível.

### 3.4 Evolução incremental
A estrutura deve permitir que novas funcionalidades sejam adicionadas sem bagunçar o projeto.

---

## 4. Pacotes principais

## 4.1 `contract`

### Objetivo
Agrupar os contratos públicos da biblioteca.

### Conteúdo esperado
- interfaces
- callbacks
- pontos de extensão expostos ao consumidor

### Classes atuais
- `Processor`
- `ChunkListener`
- `RecordErrorHandler`

### Motivo do nome
O nome `contract` representa melhor a ideia de “contrato público da biblioteca” do que `api`, que em aplicações Quarkus pode remeter a endpoint REST.

### Regra prática
Se a classe define **como o usuário conversa com a biblioteca**, ela tende a pertencer a `contract`.

---

## 4.2 `config`

### Objetivo
Agrupar tipos de configuração e políticas de comportamento.

### Conteúdo esperado
- enums
- records de configuração
- estratégias de execução
- opções funcionais que não executam o fluxo diretamente

### Classes atuais
- `ErrorStrategy`
- `TransactionMode`
- `RetryStrategy`

### Regra prática
Se a classe define **como o motor deve se comportar**, ela tende a pertencer a `config`.

---

## 4.3 `result`

### Objetivo
Agrupar objetos de retorno e resultados de execução.

### Conteúdo esperado
- records de retorno
- sumários
- estatísticas consolidadas

### Classes atuais
- `ProcessingResult`

### Possíveis evoluções futuras
- `FailureSummary`
- `ChunkSummary`
- `ProcessingStatistics`

### Regra prática
Se a classe representa **resultado produzido pelo processamento**, ela tende a pertencer a `result`.

---

## 4.4 `engine`

### Objetivo
Agrupar o motor interno da biblioteca.

### Conteúdo esperado
- implementação principal
- orquestração do fluxo
- infraestrutura do motor
- classes internas de apoio
- exceções técnicas

### Classes atuais
- `FastRecordProcessor`
- `FastRecordProcessorImpl`
- `ProcessingLoop`
- `ProcessingMetricsLogger`
- `RecordProcessingException`
- `ChunkExecutionResult`

### Motivo do nome
`engine` comunica a ideia de “motor de execução” melhor do que `core`, que muitas vezes vira um pacote genérico demais.

### Regra prática
Se a classe participa diretamente da **mecânica interna do processamento**, ela tende a pertencer a `engine`.

---

## 4.5 `sample`

### Objetivo
Agrupar exemplos de uso da biblioteca.

### Conteúdo esperado
- services demonstrativos
- exemplos de integração
- casos de uso de referência

### Classes atuais
- `CustomerBatchService`

### Regra prática
Se a classe existe para **demonstrar uso**, e não para compor o motor da biblioteca, ela tende a pertencer a `sample`.

---

## 5. Relação entre os pacotes

A dependência conceitual esperada é esta:
sample 
contract + config + result 
engine 
infraestrutura externa (Hibernate, JPA, Quarkus)


Na prática:

- `sample` usa o contrato público da biblioteca
- `engine` implementa esse contrato
- `config` orienta o comportamento do `engine`
- `result` carrega o resultado de volta ao chamador

---

## 6. O que deve entrar em cada pacote

## 6.1 Exemplos para `contract`
Entrariam bem:
- `Processor`
- `ChunkListener`
- `RecordErrorHandler`
- futuras interfaces públicas da biblioteca

Não é ideal colocar:
- enums
- classes utilitárias internas
- implementações concretas

---

## 6.2 Exemplos para `config`
Entrariam bem:
- enums de política
- records de configuração
- futuras opções como:
    - `LoggingOptions`
    - `ChunkOptions`
    - `TransactionOptions`

Não é ideal colocar:
- interfaces públicas principais
- classes que executam processamento

---

## 6.3 Exemplos para `result`
Entrariam bem:
- `ProcessingResult`
- futuros objetos de retorno

Não é ideal colocar:
- classes internas do loop
- callbacks
- estratégias

---

## 6.4 Exemplos para `engine`
Entrariam bem:
- implementação do processador
- loop de execução
- classes internas de suporte
- exceções técnicas
- consolidadores internos

Não é ideal colocar:
- exemplos de uso
- enums públicos de configuração
- contratos públicos expostos ao consumidor

---

## 6.5 Exemplos para `sample`
Entrariam bem:
- services de demonstração
- exemplos de integração
- classes usadas para explicar a biblioteca

Não é ideal colocar:
- motor da biblioteca
- contratos públicos
- infraestrutura crítica

---

## 7. O que evitar

## 7.1 Evitar pacote `api`
Em contexto Quarkus, `api` pode ser confundido com camada REST ou endpoint exposto.

## 7.2 Evitar pacote `util`
Pacotes `util` tendem a virar depósitos de tudo e enfraquecem a organização arquitetural.

## 7.3 Evitar pacote `common`
`common` geralmente não comunica responsabilidade real.

## 7.4 Evitar pacote `core` genérico
`core` costuma funcionar no começo, mas com o tempo vira um pacote superlotado e pouco descritivo.

---

## 8. Evolução futura sugerida

Se a biblioteca crescer, a estrutura pode evoluir assim:
br.com.codenest.fastrecord 
├── contract 
├── config 
├── engine 
│ ├── transaction 
│ ├── logging 
│ ├── streaming 
│ └── execution 
├── result 
├── sample 
└── testsupport


Exemplos:
- `engine.transaction`
- `engine.streaming`
- `engine.execution`

Isso faz sentido quando o motor ficar maior.

---

## 9. Sugestão de package raiz

Hoje o projeto usa: br.com.codenest

Uma evolução mais expressiva seria: br.com.codenest.fastrecord


Isso ajuda a:
- identificar melhor a biblioteca
- evitar colisão com outros módulos
- deixar o namespace mais coerente com o nome do projeto

---

## 10. Regras práticas para novos arquivos

Ao criar uma nova classe, use estas perguntas:

### A classe define o contrato público?
→ `contract`

### A classe define uma política, enum ou configuração?
→ `config`

### A classe representa um retorno ou sumário de execução?
→ `result`

### A classe executa ou coordena o motor?
→ `engine`

### A classe é só exemplo de uso?
→ `sample`

---

## 11. Resumo final

A organização atual busca deixar explícita a separação entre:

- contratos públicos
- configuração de comportamento
- motor interno
- objetos de resultado
- exemplos de uso

Essa separação melhora a legibilidade do projeto, reduz ambiguidade e prepara a biblioteca para crescer de forma mais organizada.