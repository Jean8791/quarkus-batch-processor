# quarkus-batch-processor — Processing Flow

## 1. Objetivo deste documento

Este documento descreve o fluxo de execução da biblioteca quarkus-batch-processor, do ponto de entrada até a geração do resultado final.

O foco aqui não é a organização dos pacotes, mas sim o caminho percorrido durante o processamento.

---

## 2. Visão geral do fluxo

O fluxo completo pode ser resumido assim:
text Aplicação cliente ↓ FastRecordProcessor ↓ Processor fluente ↓ FastRecordProcessorImpl.run() ↓ Abertura de StatelessSession ↓ Execução da query com ScrollableResults ↓ Conversão para Iterator ↓ ProcessingLoop ↓ Formação de chunks ↓ Processamento de cada chunk ↓ Retry / erro / transação ↓ ChunkExecutionResult ↓ ProcessingResult


---

## 3. Fluxo detalhado

## 3.1 Início: o cliente injeta o processador

A aplicação cliente injeta `FastRecordProcessor`:
java @Inject FastRecordProcessor fastRecordProcessor;


Essa classe é o ponto de entrada da biblioteca.

---

## 3.2 Escolha da entidade

O cliente informa a entidade raiz do processamento:
java fastRecordProcessor.source(CustomerEntity.class)


Nesse ponto, o tipo genérico `T` é definido.

Internamente, o método `source(...)` cria uma instância de `FastRecordProcessorImpl<T>`.

---

## 3.3 Configuração do processamento

O cliente configura a execução usando a API fluente.

Exemplo:
java fastRecordProcessor .source(CustomerEntity.class) .query("select c from CustomerEntity c where c.active = :active") .params(Map.of("active", true)) .chunkSize(2000) .transactionMode(TransactionMode.CHUNK) .onError(ErrorStrategy.CONTINUE_ON_ERROR) .retryStrategy(RetryStrategy.fixedDelay(3, 250, RuntimeException.class)) .onRecordError((customer, error) -> { System.err.println("Falha no cliente " + customer.getId()); }) .onProcess(customer -> { System.out.println("Processando " + customer.getName()); }) .onChunkComplete(processed -> { System.out.println("Total processado: " + processed); });


Até aqui, nada foi processado ainda.  
A biblioteca apenas armazenou as configurações necessárias.

---

## 3.4 Chamada de `run()`

Quando `run()` é chamado, começa a execução real.

A implementação faz:

1. validar configurações obrigatórias
2. consolidar a configuração interna
3. abrir a infraestrutura Hibernate
4. iniciar leitura em streaming
5. enviar o fluxo para o `ProcessingLoop`

---

## 3.5 Validação da configuração

Antes de processar qualquer registro, a biblioteca valida o que é obrigatório.

Exemplos de validação:
- `consumer` configurado em `onProcess(...)`
- `chunkSize > 0`
- `transactionMode` não nulo
- `retryStrategy` não nula

Essa fase evita falhas tardias e garante consistência mínima da execução.

---

## 3.6 Consolidação da configuração

Depois da validação, a implementação monta um objeto interno que representa o estado final da execução.

Esse objeto inclui:
- entidade
- query
- parâmetros
- chunk size
- modo transacional
- política de erro
- retry
- callbacks
- logging
- nome do processador

A ideia é congelar o estado da execução para que o restante do fluxo use um snapshot consistente.

---

## 3.7 Abertura da infraestrutura Hibernate

O motor obtém o `SessionFactory` a partir do `EntityManager`:
java entityManager.getEntityManagerFactory().unwrap(SessionFactory.class)


Depois abre uma `StatelessSession`.

### Por que `StatelessSession`?
Porque ela:
- não usa cache de primeiro nível
- não mantém entidades gerenciadas da mesma forma que uma `Session` normal
- reduz o custo de memória em leituras massivas

Esse é um dos pilares do projeto.

---

## 3.8 Execução da query em streaming

A query HQL é montada e executada com:

- `ScrollableResults`
- `ScrollMode.FORWARD_ONLY`

Isso faz com que os registros sejam lidos em fluxo, em vez de carregar tudo de uma vez.

### Resultado
A aplicação consegue processar volumes grandes com footprint de memória muito menor.

---

## 3.9 Adaptação para iterador

Os resultados do Hibernate são adaptados para um `Iterator<T>` através de uma classe interna.

Isso simplifica a integração com o restante da biblioteca, especialmente o `ProcessingLoop`.

---

## 3.10 Entrada no `ProcessingLoop`

O `ProcessingLoop` é responsável por:

- consumir o `Iterator<T>`
- montar os chunks
- chamar o processador de chunk
- consolidar resultados
- disparar callbacks de chunk
- liberar referências após cada bloco

Ele não sabe de Hibernate ou banco em detalhes.  
Ele trabalha com um fluxo genérico de itens e um processador de chunk.

---

## 3.11 Formação dos chunks

O loop mantém um buffer em memória com tamanho igual ao `chunkSize`.

Exemplo:
- chunk size = 2000
- ele vai adicionando registros até chegar a 2000
- ao atingir esse tamanho, processa o bloco

Depois:
- limpa o buffer
- cria um novo
- continua até o fim

### Importante
Isso mantém o uso de memória sob controle, pois o loop segura no máximo um chunk em memória, além de pequenos overheads da infraestrutura.

---

## 3.12 Processamento do chunk

Quando um chunk é formado, o `ProcessingLoop` chama um `chunkProcessor`.

Esse `chunkProcessor` é fornecido pelo `FastRecordProcessorImpl`.

Ele decide como o chunk será executado.

---

## 3.13 Modo transacional

O comportamento depende do `TransactionMode`.

### `TransactionMode.NONE`
O chunk é processado sem transação explícita por bloco.

### `TransactionMode.CHUNK`
O chunk é processado dentro de uma transação dedicada:

1. inicia transação
2. processa os registros
3. commita a transação
4. se ocorrer falha irrecuperável, faz rollback

Esse modelo permite isolar lotes e controlar melhor consistência por bloco.

---

## 3.14 Processamento registro a registro

Dentro do chunk, a implementação percorre cada entidade.

Para cada item:

1. tenta executar o `consumer`
2. se falhar, aplica retry
3. se ainda falhar:
    - registra erro
    - chama `RecordErrorHandler`, se existir
    - decide se para ou continua

---

## 3.15 Retry

O retry é controlado por `RetryStrategy`.

Ele define:
- número máximo de tentativas
- delay entre tentativas
- classes de exceção elegíveis

### Exemplo
java RetryStrategy.fixedDelay(3, 250, RuntimeException.class)


Isso significa:
- até 3 tentativas
- espera 250 ms entre elas
- só faz retry para exceções compatíveis

---

## 3.16 Política de erro

O comportamento após falha definitiva depende de `ErrorStrategy`.

### `FAIL_FAST`
O processamento é interrompido imediatamente.

### `CONTINUE_ON_ERROR`
O item é contabilizado como erro e o processamento segue para o próximo.

Essa decisão vale especialmente para o contexto de processamento por registro dentro do chunk.

---

## 3.17 `RecordErrorHandler`

Se configurado, o `RecordErrorHandler` é chamado quando um registro falha de forma definitiva.

Isso é útil para:
- log detalhado
- dead-letter
- persistência de rejeitados
- auditoria
- geração de relatórios

---

## 3.18 `ChunkExecutionResult`

Ao final do processamento de um chunk, é gerado um resultado parcial contendo:

- `processedCount`
- `errorCount`
- `retryCount`

Esse resultado representa o resumo daquele bloco específico.

---

## 3.19 Consolidação do resultado global

O `ProcessingLoop` vai somando os `ChunkExecutionResult` até obter o resultado total.

Ao final, ele monta um `ProcessingResult`.

Esse objeto consolida:
- processados com sucesso
- erros
- retries
- horário de início
- horário de fim
- duração
- throughput

---

## 3.20 Callback de chunk

Ao final de cada chunk, a biblioteca chama o `ChunkListener`:
java listener.onChunkComplete(processedCount)


O valor informado é o total acumulado de registros processados com sucesso até aquele momento.

Exemplo:
- após chunk 1 → 2000
- após chunk 2 → 4000
- após chunk 3 → 6000

---

## 3.21 Limpeza de referências

Depois de cada chunk, a biblioteca executa uma rotina de limpeza, hoje baseada em:
java entityManager.clear()


Isso ajuda a reduzir retenção de referências e manter o contexto mais limpo ao longo da execução.

---

## 3.22 Logging de progresso

Se habilitado, o processamento gera logs em três momentos principais:

### Início
- nome do processador
- entidade
- chunk size
- HQL

### Progresso
- quantidade processada
- quantidade total lida até o ponto
- ritmo de execução por chunk

### Fim
- processados
- erros
- retries
- duração
- throughput

---

## 3.23 Encerramento

Ao final do fluxo:

- a sessão é fechada
- o resultado final é retornado
- o cliente recebe um `ProcessingResult`

---

## 4. Fluxo resumido em formato operacional


1. Cliente injeta FastRecordProcessor
2. Cliente chama source(Entity.class)
3. Cliente configura execução com fluent API
4. Cliente chama run()
5. Implementação valida configuração
6. Abre StatelessSession
7. Executa query em streaming
8. Converte resultados para Iterator
10. ProcessingLoop monta chunks
11. Cada chunk é processado
12. Retry e tratamento de erro são aplicados
13. ChunkExecutionResult é gerado
14. Resultados parciais são somados
15. ProcessingResult final é retornado


---

## 5. Pontos críticos do fluxo

### 5.1 Memória
O controle de memória depende fortemente de:
- `StatelessSession`
- leitura em streaming
- chunk size adequado
- limpeza ao final do bloco

### 5.2 Transação
O comportamento transacional depende do modo escolhido.
`CHUNK` oferece isolamento por lote, mas deve ser validado com banco real.

### 5.3 Erro e retry
A combinação de:
- `RetryStrategy`
- `ErrorStrategy`
- `RecordErrorHandler`

define a resiliência operacional da biblioteca.

---

## 6. Resumo final

O fluxo do quarkus-batch-processor é orientado a:

- leitura incremental
- chunking
- processamento controlado
- isolamento transacional opcional
- observabilidade
- resiliência a falhas

A execução foi pensada para lidar com grandes volumes de registros mantendo previsibilidade de memória e comportamento configurável.